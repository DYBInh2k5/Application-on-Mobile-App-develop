import React, { Component, useState, useEffect } from "react";
import { Dimensions, StatusBar, Touchable, Pressable } from "react-native";
import Moment from 'moment';
import
{
  StyleSheet,
  View,
  Text,
  TouchableOpacity,

  TextInput,
  Image,
  TouchableWithoutFeedback, Keyboard, Modal
} from "react-native";
import Entypo from '@expo/vector-icons/Entypo'
import Ionicons from '@expo/vector-icons/Ionicons'


const CreateSavingAccount = ({ navigation }) =>
{

  const [amount, setAmount] = useState(0);
  const [term, setTerm] = useState("6 months");

  const onSave = () =>
  {
    let str = '' + Math.random();

    let account = {
      accountName: 'ACC' + str.substring(3, 7),
      balance: amount,
      date: Moment(new Date()).format('yyyy-MM-DD'),
      term: term,
      rate: 4.5,

    };
    console.log("account --> ", account);

  };

  return (

    <View style={styles.container}>
      <Text style={styles.title}>Account</Text>

      <View style={styles.formContainder}>
        <View style={styles.inputContainer}>
          <TextInput
            placeholder="Amount"
            style={styles.inputText}
            keyboardType='numeric'
            onChangeText={(value) => setAmount(value)}
          />
        </View>
        <View style={styles.inputContainer}>
          <TextInput
            placeholder="Months"

            style={styles.inputText}
            onChangeText={(value) => setTerm(value)}
          />
        </View>
        <TouchableOpacity style={styles.btn} onPress={() => onSave()}>
          <Text style={styles.btnText}> Save</Text>
        </TouchableOpacity>
      </View>
    </View>

  );
};
export default CreateSavingAccount;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",

  },

  title: {
    fontSize: 24,
    color: "#0096c7",
    fontWeight: '600',
    marginBottom: 30
  },

  formContainder: {
    width: "80%",

  },

  inputText: {
    borderBottomWidth: 2,
    borderBottomColor: "#0096c7",
    paddingVertical: 10,
    fontSize: 20,
  },
  btn: {
    backgroundColor: "#0096c7",
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
    borderRadius: 10,
  },
  btnText: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: '500'
  },
  finger: {
    flex: 1,
    //backgroundColor:'#000',
    marginTop: 20,
    alignItems: 'center',

  },


});

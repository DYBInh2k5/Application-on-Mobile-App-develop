import { View, Text, StyleSheet, Button, FlatList, TouchableOpacity } from 'react-native'
import React from 'react'
import { useState, useEffect } from 'react'


const SavingAccounts = ({ navigation }) =>
{

  const items = [
    {
      accountName: 'ACC0001',
      balance: 100,
      date: '2024-01-02',
      term: '12 months',
      rate: 4.5
    },
    {
      accountName: 'ACC0002',
      balance: 50,
      date: '2024-01-03',
      term: '6',
      rate: 4.8
    }]


  return (
    <View style={styles.container}>

      <TouchableOpacity style={styles.btn}
        onPress={() => { navigation.navigate('CreateSavingAccount') }} >
        <Text style={styles.btnText} >+ Open new online saving account</Text>
      </TouchableOpacity>
      <Text style={styles.title}>Online Saving</Text>

      <FlatList
        data={items}
        renderItem={({ item }) =>
        {
          return (
            <View style={styles.itemBox}>
              <View style={styles.box} >
                <Text style={styles.itemName}>{item.accountName}</Text>
                <Text style={styles.itemdes}>{item.date}</Text>
              </View>
              <View style={styles.box} >
                <Text style={styles.itemdes}>{item.balance} $</Text>
                <Text style={styles.itemdes}>{item.rate} %/year</Text>
              </View>
              <TouchableOpacity style={styles.btn1}>
                <Text style={styles.btnText}>Details</Text>
              </TouchableOpacity>
            </View>
          )
        }}

      />


    </View>
  )
}

export default SavingAccounts

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,

  },
  title: {
    fontSize: 24,
    color: '#0096c7',
    fontWeight: '800',
    marginBottom: 30,
  },
  btn: {
    backgroundColor: '#0096d7',
    height: 40,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30
  },
  btn1: {
    backgroundColor: '#0096d7',
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
    width: 100,
  },
  btnText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '500'
  },
  itemBox: {
    //backgroundColor:'#caf0f8',
    //borderRadius: 5,
    borderBottomWidth: 1,
    borderBottomColor: '#0096c7',
    borderStyle: 'dashed',
    marginBottom: 5,
    padding: 15
  },
  box: {
    flexDirection: 'row',
    justifyContent: 'space-between'

  },

  itemName: {
    fontSize: 20,
    textTransform: 'uppercase',
    fontWeight: '500',
    padding: 5
  },
  itemdes: {
    fontSize: 14,
    fontWeight: '300',
    padding: 5
  }
});
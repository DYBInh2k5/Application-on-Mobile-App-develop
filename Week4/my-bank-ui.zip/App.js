import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native'

import SavingAccounts from './components/SavingAccounts ';
import BankStack from './routes/BankStack';

export default function App()
{
  return (
    

      <NavigationContainer>
        <BankStack />
      </NavigationContainer>


   


  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    //alignItems:'center'  ,
    justifyContent: 'center'
  },
});

import { View, Text } from 'react-native'
import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import SavingAccounts from '../components/SavingAccounts '
import CreateSavingAccount from '../components/CreateSavingAccount'

const Stack = createNativeStackNavigator()
const BankStack = () =>
{
  return (
    <Stack.Navigator screenOptions={
      {
        headerStyle: { backgroundColor: '#0096c7' },
        headerTintColor: 'white',
      }}>
         <Stack.Screen name="OnlineSaving" component={SavingAccounts} />
 <Stack.Screen name="CreateSavingAccount" component={CreateSavingAccount} />
    </Stack.Navigator>
  )
}

export default BankStack
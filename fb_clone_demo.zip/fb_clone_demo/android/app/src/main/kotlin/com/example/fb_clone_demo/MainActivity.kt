package com.example.fb_clone_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

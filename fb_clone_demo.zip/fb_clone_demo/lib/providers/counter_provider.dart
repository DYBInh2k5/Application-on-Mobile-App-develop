import 'package:flutter/material.dart';

class CounterProvider with ChangeNotifier {
  int _likeCount = 0;

  int get likeCount => _likeCount;

  void increase() {
    _likeCount++;
    notifyListeners(); // thông báo cho UI cập nhật
  }

  void decrease() {
    if (_likeCount > 0) {
      _likeCount--;
      notifyListeners();
    }
  }
}

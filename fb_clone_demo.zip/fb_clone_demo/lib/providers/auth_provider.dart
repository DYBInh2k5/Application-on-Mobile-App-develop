import 'package:flutter_riverpod/flutter_riverpod.dart';

final authProvider = StateNotifierProvider<AuthNotifier, String?>((ref) => AuthNotifier());

class AuthNotifier extends StateNotifier<String?> {
  AuthNotifier() : super(null);

  void login(String username) => state = username;
  void logout() => state = null;
}

import 'package:flutter/material.dart';
import '../models/post.dart';
import '../services/post_service.dart';

class PostItem extends StatefulWidget {
  final Post post;
  final VoidCallback? onTap;

  const PostItem({super.key, required this.post, this.onTap});

  @override
  State<PostItem> createState() => _PostItemState();
}

class _PostItemState extends State<PostItem> {
  final PostService _service = PostService();

  void _toggleLike() {
    setState(() {
      _service.toggleLike(widget.post.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.post;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // header
            Row(
              children: [
                CircleAvatar(backgroundImage: NetworkImage(p.avatar)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(p.author, style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
                Text(p.timestamp.split('T').first, style: const TextStyle(color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 10),
            // content
            Text(p.content),
            if (p.image != null) ...[
              const SizedBox(height: 10),
              Image.network(p.image!, fit: BoxFit.cover),
            ],
            const SizedBox(height: 8),
            // actions
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    _toggleLike();
                    setState(() {}); // refresh to show like count
                  },
                  icon: Icon(
                    p.isLiked ? Icons.thumb_up : Icons.thumb_up_outlined,
                    color: p.isLiked ? Colors.blue : null,
                  ),
                ),
                Text('${p.likes}'),
                const SizedBox(width: 20),
                IconButton(
                  onPressed: widget.onTap,
                  icon: const Icon(Icons.comment_outlined),
                ),
                Text('${p.comments}'),
                const Spacer(),
                IconButton(
                  onPressed: () {
                    // share placeholder
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Share (demo)')));
                  },
                  icon: const Icon(Icons.share_outlined),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

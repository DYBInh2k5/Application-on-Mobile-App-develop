import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/post.dart';

class PostService {
  PostService._privateConstructor();
  static final PostService _instance = PostService._privateConstructor();
  factory PostService() => _instance;

  final List<Post> _posts = [];

  List<Post> get posts => _posts;

  Future<void> loadPostsFromAssets() async {
    if (_posts.isNotEmpty) return; // avoid reloading
    final data = await rootBundle.loadString('assets/data/posts.json');
    final List<dynamic> jsonList = json.decode(data);
    int nextId = 1;
    for (var item in jsonList) {
      final post = Post.fromJson(item);
      _posts.add(post);
      if (post.id >= nextId) nextId = post.id + 1;
    }
    _nextId = nextId;
  }

  int _nextId = 1;
  int _generateId() => _nextId++;

  void addPost({required String author, required String content, String? image}) {
    final post = Post(
      id: _generateId(),
      author: author,
      avatar: "https://i.pravatar.cc/100?u=${_generateId()}",
      content: content,
      image: image,
      likes: 0,
      comments: 0,
      timestamp: DateTime.now().toIso8601String(),
    );
    _posts.insert(0, post); // newest on top
  }

  void toggleLike(int id) {
    final idx = _posts.indexWhere((p) => p.id == id);
    if (idx == -1) return;
    final p = _posts[idx];
    p.isLiked = !p.isLiked;
    p.likes += p.isLiked ? 1 : -1;
  }

  Post? getById(int id) {
  try {
    return _posts.firstWhere((p) => p.id == id);
  } catch (_) {
    return null;
  }
}

}

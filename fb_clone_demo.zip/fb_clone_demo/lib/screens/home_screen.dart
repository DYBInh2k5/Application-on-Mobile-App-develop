import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/theme_provider.dart';
import '../providers/post_provider.dart';
import '../models/post.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = ref.watch(themeProvider);
    final posts = ref.watch(postProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Facebook Feed"),
        actions: [
          IconButton(
            icon: Icon(isDark ? Icons.dark_mode : Icons.light_mode),
            onPressed: () => ref.read(themeProvider.notifier).toggle(),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          final post = posts[index];
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              title: Text(post.author),
              subtitle: Text(post.content),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ref.read(postProvider.notifier).addPost(
                Post(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  author: "Duy Bình",
                  content: "Bài viết mới lúc ${DateTime.now()}",
                ),
              );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

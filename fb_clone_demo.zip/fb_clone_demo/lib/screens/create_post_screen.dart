import 'package:flutter/material.dart';
import '../services/post_service.dart';

class CreatePostScreen extends StatefulWidget {
  const CreatePostScreen({super.key});
  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  final TextEditingController _txt = TextEditingController();
  final TextEditingController _img = TextEditingController();
  final PostService _service = PostService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tạo bài mới')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              controller: _txt,
              maxLines: 5,
              decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Bạn đang nghĩ gì?'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _img,
              decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Link ảnh (tùy chọn)'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                final content = _txt.text.trim();
                if (content.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Viết nội dung trước đã')));
                  return;
                }
                _service.addPost(author: 'Bạn (demo)', content: content, image: _img.text.trim().isEmpty ? null : _img.text.trim());
                Navigator.pop(context, true); // signal success
              },
              child: const Text('Đăng'),
            ),
          ],
        ),
      ),
    );
  }
}

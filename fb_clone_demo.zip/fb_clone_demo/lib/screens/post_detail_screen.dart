import 'package:flutter/material.dart';
import '../services/post_service.dart';
import '../models/post.dart';

class PostDetailScreen extends StatefulWidget {
  final int postId;
  const PostDetailScreen({super.key, required this.postId});

  @override
  State<PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen> {
  final PostService _service = PostService();
  Post? _post;

  @override
  void initState() {
    super.initState();
    _post = _service.getById(widget.postId);
  }

  void _toggleLike() {
    setState(() {
      _service.toggleLike(widget.postId);
      _post = _service.getById(widget.postId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = _post;
    if (p == null) return Scaffold(body: Center(child: Text('Post not found')));

    return Scaffold(
      appBar: AppBar(title: const Text('Chi tiết bài viết')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(backgroundImage: NetworkImage(p.avatar)),
                const SizedBox(width: 10),
                Text(p.author, style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                Text(p.timestamp.split('T').first, style: const TextStyle(color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 12),
            Text(p.content),
            if (p.image != null) ...[
              const SizedBox(height: 12),
              Image.network(p.image!),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton(
                  onPressed: _toggleLike,
                  icon: Icon(p.isLiked ? Icons.thumb_up : Icons.thumb_up_outlined, color: p.isLiked ? Colors.blue : null),
                ),
                Text('${p.likes}'),
                const SizedBox(width: 16),
                Icon(Icons.comment_outlined),
                const SizedBox(width: 6),
                Text('${p.comments} bình luận'),
              ],
            ),
            const Divider(),
            const SizedBox(height: 8),
            const Text('Bình luận (demo)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: const [
                ListTile(leading: CircleAvatar(child: Text('A')), title: Text('Nguyễn Văn A: Hay quá!')),
                ListTile(leading: CircleAvatar(child: Text('B')), title: Text('Trần Thị B: Chúc mừng nhé!')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Post {
  final String id;
  final String author;
  final String content;

  Post({
    required this.id,
    required this.author,
    required this.content,
  });
}


import { Dimensions, StatusBar, Touchable ,Pressable} from "react-native";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Image,
  TouchableWithoutFeedback
  
} from "react-native";
import FontAwesome from "react-native-vector-icons/FontAwesome";

const LoginView = ({ }) => {
      
   
  const onLogin = () => {
   
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}> 
      <View style={styles.loginContainer}>
        <View style={styles.logoLogin}>
          <FontAwesome name="user" color="#FFFFFF" size={36} />
        </View>
        <Text style={styles.textSignin}>Sign in</Text>

        <View style={styles.formContainder}>
          <View style={styles.inputContainer}>
            <TextInput
              placeholder="Email"
              style={styles.inputText}
              
            />
          </View>
          <View style={styles.inputContainer}>
            <TextInput
              placeholder="Password"
              secureTextEntry="true"
              returnKeyType="done"
              style={styles.inputText}
              
            />
          </View>
          <TouchableOpacity style={styles.btn} onPress={() => onLogin()}>
            <Text style={styles.btnText}> Sign in</Text>
          </TouchableOpacity>

          <Text style={styles.signupText}>Need an account? 
                  <TouchableOpacity >
                    <Text style={styles.loginText}>Sign up</Text>
                  </TouchableOpacity>
           </Text>
                    

        </View>
      </View>
      </TouchableWithoutFeedback>
  );
};
export default LoginView;

const styles = StyleSheet.create({
  loginContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  logoLogin: {
    width: 60,
    height: 60,
    borderRadius: 60 / 2,
    backgroundColor: "#d81b60",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  textSignin: {
    fontSize: 24,
    color: "#d81b60",
  },
  formContainder: {
    width: "90%",
    // backgroundColor: 'black'
  },

  inputText: {
    borderBottomWidth: 2,
    borderBottomColor: "#d81b60",
    paddingVertical: 10,
    fontSize: 20,
  },
  btn: {
    backgroundColor: "#d81b60",
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
    borderRadius: 10,
  },
  btnText: {
    color: "#FFFFFF",
  },
  signupText: {
    color: "#d81b60",
    fontSize: 14,
    textAlign:'right',
    marginTop: 10
  },
  loginText: {
    color: "#0000FF",
    fontSize: 14,
    textAlign:'right',
    marginTop: 10
  }
  
});

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/note_model.dart';

class NoteService {
  final CollectionReference notesRef =
      FirebaseFirestore.instance.collection("notes");

  Future<void> addNote(NoteModel note) {
    return notesRef.add(note.toJson());
  }

  Future<void> updateNote(NoteModel note) {
    return notesRef.doc(note.id).update(note.toJson());
  }

  Future<void> deleteNote(String id) {
    return notesRef.doc(id).delete();
  }

  Stream<List<NoteModel>> getNotes() {
    return notesRef.orderBy("createdAt", descending: true).snapshots().map(
      (snapshot) {
        return snapshot.docs
            .map((doc) => NoteModel.fromJson(doc.id, doc.data() as Map<String, dynamic>))
            .toList();
      },
    );
  }
}

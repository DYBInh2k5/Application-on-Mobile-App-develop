class NoteModel {
  String id;
  String title;
  String content;
  String? imageUrl;
  DateTime createdAt;

  NoteModel({
    required this.id,
    required this.title,
    required this.content,
    this.imageUrl,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        "title": title,
        "content": content,
        "imageUrl": imageUrl,
        "createdAt": createdAt.toIso8601String(),
      };

  factory NoteModel.fromJson(String id, Map<String, dynamic> json) {
    return NoteModel(
      id: id,
      title: json["title"],
      content: json["content"],
      imageUrl: json["imageUrl"],
      createdAt: DateTime.parse(json["createdAt"]),
    );
  }
}

import 'package:flutter/material.dart';
import '../models/note_model.dart';
import '../services/note_service.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Ghi chú Firebase")),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, "/add"),
        child: Icon(Icons.add),
      ),
      body: StreamBuilder<List<NoteModel>>(
        stream: NoteService().getNotes(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          final notes = snapshot.data!;
          return ListView.builder(
            itemCount: notes.length,
            itemBuilder: (_, i) {
              final note = notes[i];
              return ListTile(
                leading: note.imageUrl != null
                    ? Image.network(note.imageUrl!, width: 60, height: 60, fit: BoxFit.cover)
                    : Icon(Icons.note),
                title: Text(note.title),
                subtitle: Text(note.content),
                onTap: () {
                  Navigator.pushNamed(context, "/edit", arguments: note);
                },
              );
            },
          );
        },
      ),
    );
  }
}

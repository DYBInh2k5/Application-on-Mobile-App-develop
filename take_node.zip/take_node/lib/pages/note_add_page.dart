import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/note_model.dart';
import '../services/note_service.dart';
import '../services/storage_service.dart';

class NoteAddPage extends StatefulWidget {
  @override
  _NoteAddPageState createState() => _NoteAddPageState();
}

class _NoteAddPageState extends State<NoteAddPage> {
  final titleCtrl = TextEditingController();
  final contentCtrl = TextEditingController();

  File? image;
  final picker = ImagePicker();

  Future pickImage() async {
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => image = File(picked.path));
    }
  }

  Future saveNote() async {
    String? imageUrl;

    if (image != null) {
      imageUrl = await StorageService().uploadImage(image!);
    }

    final newNote = NoteModel(
      id: "",
      title: titleCtrl.text,
      content: contentCtrl.text,
      imageUrl: imageUrl,
      createdAt: DateTime.now(),
    );

    await NoteService().addNote(newNote);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Thêm ghi chú")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(controller: titleCtrl, decoration: InputDecoration(labelText: "Tiêu đề")),
            TextField(controller: contentCtrl, decoration: InputDecoration(labelText: "Nội dung")),
            SizedBox(height: 10),
            image != null 
              ? Image.file(image!, height: 120)
              : Text("Chưa chọn ảnh"),
            ElevatedButton(onPressed: pickImage, child: Text("Chọn ảnh")),
            Spacer(),
            ElevatedButton(onPressed: saveNote, child: Text("Lưu"))
          ],
        ),
      ),
    );
  }
}

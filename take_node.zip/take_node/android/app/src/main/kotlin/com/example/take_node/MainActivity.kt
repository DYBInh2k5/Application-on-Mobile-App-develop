package com.example.take_node

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
